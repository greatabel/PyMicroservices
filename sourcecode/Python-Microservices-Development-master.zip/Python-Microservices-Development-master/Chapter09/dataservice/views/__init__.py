from .home import home
from .swagger import api

blueprints = [home, api]
